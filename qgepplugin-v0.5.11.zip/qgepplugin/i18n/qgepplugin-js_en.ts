<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>reach</name>
    <message>
        <source>Reach</source>
        <comment>Reach</comment>
        <translation>Reach</translation>
    </message>
    <message>
        <source>Material:</source>
        <comment>Material:</comment>
        <translation>Material:</translation>
    </message>
    <message>
        <source>Width:</source>
        <comment>Width:</comment>
        <translation>Width:</translation>
    </message>
    <message>
        <source>Length:</source>
        <comment>Length:</comment>
        <translation>Length:</translation>
    </message>
    <message>
        <source>Gradient:</source>
        <comment>Gradient:</comment>
        <translation>Gradient:</translation>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation>Entry level:</translation>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation>Exit level:</translation>
    </message>
</context>
<context>
    <name>specialStructure</name>
    <message>
        <source>Manhole</source>
        <comment>Manhole</comment>
        <translation>Manhole</translation>
    </message>
    <message>
        <source>Cover level:</source>
        <comment>Cover level:</comment>
        <translation>Cover level:</translation>
    </message>
    <message>
        <source>Bottom level:</source>
        <comment>Bottom level:</comment>
        <translation>Bottom level:</translation>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation>Entry level:</translation>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation>Exit level:</translation>
    </message>
</context>
</TS>
