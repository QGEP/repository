<?xml version="1.0" ?><!DOCTYPE TS><TS language="it" sourcelanguage="en" version="2.0">
 <context>
  <name>fld_vw_qgep_cover</name>
  <message>
   <source>special_structure_function</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>diameter</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_owner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>contract_section</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>inspection_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>cover_material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>subsidies</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>accessibility</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dimension1</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_necessity</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>sludge_bucket</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>waterlevel_hydraulic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>gross_costs</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>defects</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>manhole_orientation</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_construction_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>absorption_capacity</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>channel_function_hierarchic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>financing</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>replacement_value</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>location_name</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>manhole_function</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>upper_elevation</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>effective_area</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>venting</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>positional_accuracy</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>bypass</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>relevance</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>structure_condition</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>stormwater_tank_arrangement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_base_year</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>surface_inflow</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>seepage_utilization</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>brand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>ws_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>ws_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>records</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>emergency_spillway</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>distance_to_aquifer</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fastening</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>highwater_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>vehicle_access</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_replacement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dimension2</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>terrain_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>channel_usage_current</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_operator</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>cover_shape</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>depth</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>status</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_construction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>watertightness</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>labeling</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>bottom_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>backflow_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wn_identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_access_aid</name>
  <message>
   <source>kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_od_pipe_profile</name>
  <message>
   <source>od_pipe_profile</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_dryweather_flume</name>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_qgep_reach</name>
  <message>
   <source>vw_qgep_reach</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_od_maintenance_event</name>
  <message>
   <source>status</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>cost</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>data_details</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>operator</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>reason</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>base_data</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>result</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>time_point</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>duration</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_cover</name>
  <message>
   <source>diameter</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>brand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>sludge_bucket</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>cover_shape</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>depth</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>venting</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>positional_accuracy</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fastening</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_od_pipe_profile</name>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>profile_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>old_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>height_width_ratio</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_dryweather_downspout</name>
  <message>
   <source>diameter</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_backflow_prevention</name>
  <message>
   <source>vw_backflow_prevention</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_channel</name>
  <message>
   <source>vw_channel</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_qgep_reach</name>
  <message>
   <source>inspection_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>length_effective</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>contract_section</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_owner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>reliner_nominal_size</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>subsidies</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_construction_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>accessibility</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_outlet_shape</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_necessity</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>usage_current</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>clear_height</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>gross_costs</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>wall_roughness</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_outlet_shape</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>progression_3d_geometry</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_identifier</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_operator</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>connection_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>replacement_value</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>location_name</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_construction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>inside_coating</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_pipe_profile</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>width</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_position_of_connection</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>elevation_determination</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>function_hydraulic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_base_year</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>slope_per_mill</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>structure_condition</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>ws_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>pipe_length</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>records</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_position_of_connection</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>relining_construction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_fk_wastewater_networkelement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_elevation_accuracy</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>financing</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_replacement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>function_hierarchic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_level</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>horizontal_positioning</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>coefficient_of_friction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_elevation_accuracy</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>reliner_material</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_to_dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>relining_kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>ring_stiffness</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>jetting_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>status</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_identifier</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>usage_planned</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rp_from_fk_wastewater_networkelement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>slope_building_plan</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_dryweather_downspout</name>
  <message>
   <source>vw_dryweather_downspout</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_benching</name>
  <message>
   <source>vw_benching</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_backflow_prevention</name>
  <message>
   <source>kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_replacement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>gross_costs</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_qgep_cover</name>
  <message>
   <source>vw_qgep_cover</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_access_aid</name>
  <message>
   <source>vw_access_aid</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_channel</name>
  <message>
   <source>inspection_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>contract_section</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_owner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>subsidies</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>accessibility</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_necessity</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>usage_current</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>gross_costs</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_construction_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>connection_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>replacement_value</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>location_name</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>function_hydraulic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>detail_geometry_geometry</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_base_year</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>structure_condition</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_construction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>pipe_length</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>records</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>detail_geometry_3d_geometry</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>financing</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_replacement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>function_hierarchic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>bedding_encasement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_operator</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>jetting_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>status</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>usage_planned</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_dryweather_flume</name>
  <message>
   <source>vw_dryweather_flume</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_vw_cover</name>
  <message>
   <source>vw_cover</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_od_maintenance_event</name>
  <message>
   <source>od_maintenance_event</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_vw_benching</name>
  <message>
   <source>kind</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_demand</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>lyr_od_wastewater_structure</name>
  <message>
   <source>od_wastewater_structure</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>fld_od_wastewater_structure</name>
  <message>
   <source>inspection_interval</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>contract_section</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_owner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>subsidies</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>accessibility</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>renovation_necessity</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>gross_costs</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_construction_type</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>replacement_value</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>location_name</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>dataowner</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>old_obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>provider</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>_function_hierarchic</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>rv_base_year</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>structure_condition</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>remark</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>records</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>detail_geometry_3d_geometry</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>financing</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_replacement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>obj_id</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>_usage_current</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>fk_operator</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>status</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>last_modification</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>year_of_construction</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>identifier</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>frm_vw_qgep_reach</name>
  <message>
   <source>From</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Wastewater Structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Wastewater Networkelement</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Reach</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>General</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>To</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Reach Points</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Maintenance</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Channel</source>
   <translation type="unfinished"/>
  </message>
 </context>
 <context>
  <name>frm_vw_qgep_cover</name>
  <message>
   <source>Dryweather Flume</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Special Structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Wastewater Structure</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Wastewater Node</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Cover</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Covers</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>General</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Infiltration Installation</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Dryweather Downspout</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Manhole</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Maintenance</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Benching</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Access Aid</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Backflow Prevention</source>
   <translation type="unfinished"/>
  </message>
  <message>
   <source>Discharge Point</source>
   <translation type="unfinished"/>
  </message>
 </context>
</TS>