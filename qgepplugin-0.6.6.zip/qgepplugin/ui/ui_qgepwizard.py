# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/qgepwizard.ui'
#
# Created: Tue Sep 12 07:48:34 2017
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_QgepDockWidget(object):
    def setupUi(self, QgepDockWidget):
        QgepDockWidget.setObjectName(_fromUtf8("QgepDockWidget"))
        QgepDockWidget.resize(327, 136)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.gridLayout = QtGui.QGridLayout(self.dockWidgetContents)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(self.dockWidgetContents)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.stateButton = QtGui.QPushButton(self.dockWidgetContents)
        self.stateButton.setObjectName(_fromUtf8("stateButton"))
        self.gridLayout.addWidget(self.stateButton, 0, 0, 1, 2)
        self.layerComboBox = QtGui.QComboBox(self.dockWidgetContents)
        self.layerComboBox.setEnabled(False)
        self.layerComboBox.setAutoFillBackground(True)
        self.layerComboBox.setObjectName(_fromUtf8("layerComboBox"))
        self.gridLayout.addWidget(self.layerComboBox, 1, 1, 1, 2)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 2, 0, 1, 1)
        QgepDockWidget.setWidget(self.dockWidgetContents)

        self.retranslateUi(QgepDockWidget)
        QtCore.QMetaObject.connectSlotsByName(QgepDockWidget)

    def retranslateUi(self, QgepDockWidget):
        QgepDockWidget.setWindowTitle(_translate("QgepDockWidget", "QGEP Data Entry", None))
        self.label.setText(_translate("QgepDockWidget", "Create", None))
        self.stateButton.setText(_translate("QgepDockWidget", "Start Data Entry", None))

