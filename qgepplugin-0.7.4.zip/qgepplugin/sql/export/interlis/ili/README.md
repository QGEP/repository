Add the INTERLIS 2.3 modell files in this folder. 

You need to have the necessary model files in this subfolder ili:

For Schema VSA_DSS_2015_2:

    Units.ili
    Base.ili
    SIA405_Base.ili
    VSA_DSS_2015_2_d.ili

For schema SIA405_Abwasser_2015_2:


    units.ili
    base.ili
    sia405_base.ili
    SIA405_Abwasser_2015_2_d.ili


License for use needed from VSA or sia:
You can get it by purchasing Norm SIA405 2016 (http://www.webnorm.ch/null/null/sia%202016/d/2012/D/Product) 
or VSA-DSS CD (https://dss.vsa.ch)
