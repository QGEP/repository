<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>reach</name>
    <message>
        <source>Reach</source>
        <comment>Reach</comment>
        <translation>Conduite</translation>
    </message>
    <message>
        <source>Material:</source>
        <comment>Material:</comment>
        <translation>Matériau:</translation>
    </message>
    <message>
        <source>Width:</source>
        <comment>Width:</comment>
        <translation>Largeur:</translation>
    </message>
    <message>
        <source>Length:</source>
        <comment>Length:</comment>
        <translation>Longueur:</translation>
    </message>
    <message>
        <source>Gradient:</source>
        <comment>Gradient:</comment>
        <translation>Gradient: </translation>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation>Cote d&apos;entrée:</translation>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation>Cote de sortie:</translation>
    </message>
</context>
<context>
    <name>specialStructure</name>
    <message>
        <source>Manhole</source>
        <comment>Manhole</comment>
        <translation>Chambre:</translation>
    </message>
    <message>
        <source>Cover level:</source>
        <comment>Cover level:</comment>
        <translation>Cote du couvercle:</translation>
    </message>
    <message>
        <source>Bottom level:</source>
        <comment>Bottom level:</comment>
        <translation>Cote du radier:</translation>
    </message>
    <message>
        <source>Entry level:</source>
        <comment>Entry level:</comment>
        <translation>Cote d&apos;entrée:</translation>
    </message>
    <message>
        <source>Exit level:</source>
        <comment>Exit level:</comment>
        <translation>Cote de sortie:</translation>
    </message>
</context>
</TS>